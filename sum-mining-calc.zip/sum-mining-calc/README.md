# Sumcoin Mining Profit Calculator

## A simple html/js Sumcoin mining calculator 

### Add to server and run on port 80 using index.html




## Rate ad difficulty sources
https://rates.sumcoinindex.com/api/rates
https://sumcoinindex.com/rates/price2.json
https://rates.slicewallet.org/api/rates
